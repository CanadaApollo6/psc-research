UBASH3A CD4 laboratory feasibility packet, 2026-09-14.
Read START-HERE.md, then ubash3a-cd4-analysis-plan.md.
DESIGN ONLY. No bench experiment, donor measurements, validated primers, orders or contacts.
All three measurement templates are intentionally header-only.
Reference FASTA sequences are conditional planning inputs, not experimentally observed full RNAs.
proposed-design.json has unset laboratory fields; it is not a frozen confirmatory protocol.
Input paths in that file identify the source research repository, not files to load from this ZIP.
Published references in method-sources.csv describe methodological precedents, not validation here.
Included reference chains have 10 rows; assay-targets.csv adds the exploratory TRAILS model.
PACKAGE-MANIFEST.json lists SHA-256 hashes for every other member.
